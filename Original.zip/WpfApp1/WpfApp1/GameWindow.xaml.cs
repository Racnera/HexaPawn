﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for GameWindow.xaml
    /// </summary>
    public partial class GameWindow : Window
    {


        /// <summary>
        /// globals
        /// </summary>
        char[] letter = { 'C', 'B', 'A' };       //shows on side what square you have selected
        char[] num = { '_', '1', '2', '3', '_' };   // ||
        int pawnDiam = 90; //pawn dimension 
        int[,] boardStart = new int[,] //plceholder board
        {
            {0,1,1,1,0 },//black        //black is 1 so when i check moves later, i can add "turn" and get squares below piece selected
            {0,0,0,0,0 },//blank
            {0,-1,-1,-1,0 }//white      //white is -1 so when i check moves later, i can add "turn" and get squares above piece selected 
        }; //game board
        int[,] board = new int[,]       //BOARD THAT IS PLAYED ON/UPDATED
        {                               //5x by 3y grid makes it easier to check valid moves later
            {0,1,1,1,0 },//black        //black is 1 so when i check moves later, i can add "turn" and get squares below piece selected
            {0,0,0,0,0 },//blank
            {0,-1,-1,-1,0 }//white      //white is -1 so when i check moves later, i can add "turn" and get squares above piece selected 
        }; //game board
        bool pieceSelected = false;     //if a square is selected
        int slectX;                     //placeholder, found when pieceSelected=false
        int slectY;                     //placeholder
        int turn = -1;                  //-1=white, 1=black
        int moveX;                      //future position, found when pieceSelected=true
        int moveY;                      //||
        int whitePoints;                //score
        int blackPoints;                //score
        int blackPawns = 0;               //pawn on board
        int whitePawns = 0;               //pawns on board
        public GameWindow()
        {
            InitializeComponent();
            drawGame();                        //draws pawn locations, and character board (lblBoard)
            lblTurn.Content = "White's Turn!"; //white goes first

        }

        //board buttons/squares
        private void C3_Click(object sender, RoutedEventArgs e)
        {
            if (pieceSelected == false)             //if a piece has not been selected yet                        
            {
                C3.Background = Brushes.Green;        //highlight the piece selected
                slectX = 3;                         //Square's x value in the array 'board'
                slectY = 0;                         //square's y value in the array 'board'
                pieceSelect();


            }
            else if (pieceSelected == true)         //if a piece has been selected
            {
                moveX = 3;                          //square's X value
                moveY = 0;                          //square's Y value
                if (checkMove() == true)            //if the move is allowed
                {
                    updateBoard();                  //redraws the board
                }
            }
            //Code is same for all buttons, only the variables slectX,slectY,moveX,moveY, 
            //change based on which button is pressed
        }
        private void C2_Click(object sender, RoutedEventArgs e)
        {
            if (pieceSelected == false)
            {
                C2.Background = Brushes.Green;
                slectX = 2;
                slectY = 0;
                pieceSelect();


            }

            else if (pieceSelected == true)
            {
                moveX = 2;
                moveY = 0;
                if (checkMove() == true)
                {
                    updateBoard();                         //redraws the board

                }

            }
        }
        private void C1_Click(object sender, RoutedEventArgs e)
        {
            if (pieceSelected == false)
            {
                C1.Background = Brushes.Green;
                slectX = 1;
                slectY = 0;
                pieceSelect();

            }


            else if (pieceSelected == true)
            {
                moveX = 1;
                moveY = 0;
                if (checkMove() == true)
                {
                    updateBoard();                         //redraws the board
                }

            }
        }
        private void B3_Click(object sender, RoutedEventArgs e)
        {
            if (pieceSelected == false)
            {
                B3.Background = Brushes.Green;
                slectX = 3;
                slectY = 1;
                pieceSelect();


            }
            else if (pieceSelected == true)
            {
                moveX = 3;
                moveY = 1;
                if (checkMove() == true)
                {
                    updateBoard();                         //redraws the board
                }

            }

        }
        private void B2_Click(object sender, RoutedEventArgs e)
        {
            if (pieceSelected == false)
            {
                B2.Background = Brushes.Green;
                slectX = 2;
                slectY = 1;
                pieceSelect();

            }


            else if (pieceSelected == true)
            {
                moveX = 2;
                moveY = 1;
                if (checkMove() == true)
                {
                    updateBoard();                         //redraws the board
                }

            }
            //Console.WriteLine(turn.ToString());
        }
        private void B1_Click(object sender, RoutedEventArgs e)
        {
            if (pieceSelected == false)
            {
                B1.Background = Brushes.Green;
                slectX = 1;
                slectY = 1;
                pieceSelect();

            }
            else if (pieceSelected == true)
            {
                moveX = 1;
                moveY = 1;
                if (checkMove() == true)
                {
                    updateBoard();                         //redraws the board
                }

            }
        }
        private void A3_Click(object sender, RoutedEventArgs e)
        {
            if (pieceSelected == false)
            {
                A3.Background = Brushes.Green;
                slectX = 3;
                slectY = 2;
                pieceSelect();


            }
            else if (pieceSelected == true)
            {
                moveX = 3;
                moveY = 2;
                if (checkMove() == true)
                {
                    updateBoard();                         //redraws the board
                }

            }
        }
        private void A2_Click(object sender, RoutedEventArgs e)
        {
            if (pieceSelected == false)
            {
                A2.Background = Brushes.Green;
                slectX = 2;
                slectY = 2;
                pieceSelect();

            }
            else if (pieceSelected == true)
            {
                moveX = 2;
                moveY = 2;
                if (checkMove() == true)
                {
                    updateBoard();                         //redraws the board
                }

            }

        }
        private void A1_Click(object sender, RoutedEventArgs e)
        {
            if (pieceSelected == false)
            {
                A1.Background = Brushes.Green;
                slectX = 1;
                slectY = 2;
                pieceSelect();


            }
            else if (pieceSelected == true)
            {
                moveX = 1;
                moveY = 2;
                if (checkMove() == true)
                {
                    updateBoard();                         //redraws the board
                }

            }

        }

        /// <summary>
        /// updates the board with the pawn's new locations, updates character board as well
        /// </summary>
        private void updateBoard()
        {
            blackPawns = 0;                 //pawns alive
            whitePawns = 0;                 //||
            refreshBoard();
            canPawn.Children.Clear();       //clear all the pawns off the board
            pieceSelected = false;          //piece select had to be true to get here, see pieceSelect()
            lblBoard.Content = "";          //reset character board
            for (int y = 0; y <= 2; y++)    //check through Y values of the grid
            {
                for (int x = 0; x <= 4; x++)//check through X values of grid
                {

                    if (x != 4)               //small time save, ignores X-values always set to 0/Blank. also makes the character board cleaner 
                    {
                        if (x != 0)         //      ||
                        {
                            if (board[y, x] == 1) //check if the square
                            {
                                blackPawns++;
                                Ellipse BP = new Ellipse();             //pawn figure
                                BP.Height = pawnDiam;                   //pawn size
                                BP.Width = pawnDiam;                    //||
                                BP.Fill = Brushes.Black;                //black pawn is black
                                BP.Stroke = Brushes.White;              //see the black pawns on the black tiles
                                BP.StrokeThickness = 1;
                                lblBoard.Content += "B ";                //character board representation as 'B'
                                canPawn.Children.Add(BP);               //draw pawn
                                Canvas.SetLeft(BP, (100 * (x - 1)) + 5);  //position pawn as according to its place in board[,]
                                Canvas.SetTop(BP, (100 * (y)) + 5);     //||
                            }
                            else if (board[y, x] == -1)                  //white pawns, see black pawns
                            {
                                whitePawns++;
                                Ellipse WP = new Ellipse();             //pawn figure
                                WP.Height = pawnDiam;
                                WP.Width = pawnDiam;
                                WP.Fill = Brushes.White;
                                WP.Stroke = Brushes.Black;
                                WP.StrokeThickness = 1;

                                lblBoard.Content += "W ";                //character board representation as 'W'
                                canPawn.Children.Add(WP);
                                Canvas.SetLeft(WP, (100 * (x - 1)) + 5);
                                Canvas.SetTop(WP, (100 * (y)) + 5);
                            }
                            else
                            {
                                lblBoard.Content += "- ";                //if theres no pawn, character board representation as '-', since '_' dont work well
                            }
                            //lblBoard.Content += board[y, x].ToString() //old character board design used the values on board[,]; change for readability
                        }
                    }

                    //Console.WriteLine(board[y, x].ToString());         //debugging before i built the character board
                    if (x == 4)
                    {
                        lblBoard.Content += "\n";                        //adds next line in character board when the loop ends and moves to the next y value
                    }
                }
            }
            checkEnd();// check if the game is over, see method
            turnSwitch(); //switches turns, see method
        }

        /// <summary>
        /// Ethan Hunter
        /// checks if your move is valid

        /// this could probably be one if statement, but it would have an || statement in it
        /// and it would look even more messy than it currently is
        /// </summary>

        private bool checkMove()
        {

            //if  Y-value of square you want to move to is equal to your current square + (1 if black, -1 if white) 
            // & where you want to move has the same X value as your current square
            // & your future square is blank
            if ((moveY == slectY + turn) && (moveX == slectX) && board[moveY, moveX] == 0) //check if moving to a legal, empty tile (not diag, sideways, or more than 1 square//
            {
                board[moveY, moveX] = turn;            //your piece moves to the selected position
                board[slectY, slectX] = 0;             //board at your piece's lastposition is set to blank
                Errors.Content = "";                   //no errors
                return true;                           // move is legal
            }

            //capturing pieces
            //if  Y-value of square you want to move to is equal to your current square + (1 if black, -1 if white) 
            // & where you want to move has an X value of +-1 your current square
            // & your future square has an enemy piece on it
            else if ((moveY == slectY + turn) &&
                       (moveX == slectX + turn ||
                       moveX == slectX - turn) &&
                       board[moveY, moveX] == (turn * -1))
            {
                board[moveY, moveX] = turn;             //your piece moves to the selected position
                board[slectY, slectX] = 0;              //board at your piece's lastposition is set to blank
                Errors.Content = "";                    //no errors
                return true;                            //move is legal
            }
            else if ((moveY == slectY) && moveX == slectX)
            {//
                refreshBoard();                         //change tile colour back to normal
                pieceSelected = false;                  //clears selection
                return false;
            }
            else { Errors.Content = "Invalid Move"; pieceSelected = false; return false; } //illegal move 

            lblSelected.Content = "No piece selected";   //clears your selection              
            lblSelectedBool.Content = pieceSelected;

        }
        /// <summary>
        /// checks if you're going to move one of your own pieces
        /// </summary>
        /// <returns>
        /// trueif it's your piece, false if it isn't
        /// </returns>

        private bool pieceSelect()
        {
            lblSelected.Content = letter[slectY].ToString() + num[slectX].ToString();

            if (board[slectY, slectX] == turn) //if selecting a valid piece (a white piece on white's turn)
            {
                lblSelectedBool.Content = pieceSelected.ToString();
                Errors.Content = "";
                return pieceSelected = true;

            }
            else
            {
                Errors.Content = "Please select a square with one of your own pieces";
                lblSelectedBool.Content = pieceSelected.ToString();
                refreshBoard();
                return pieceSelected = false;
            }

        }
        /// <summary>
        /// switches turns
        /// </summary>
        private void turnSwitch()
        {
            if (turn == 1)
            {
                turn -= 2;
                lblTurn.Content = "White's Turn!";
            }
            else if (turn == -1)
            {
                turn += 2;
                lblTurn.Content = "Black's Turn!";
            }
        }

        /// <summary>
        /// runs when the game is completed
        /// </summary>
        private void resetGame()
        {

            turn = (-1);                              //white goes first'
            turn = turn * -1;                         //i dont know it just makes it work.
            canPawn.Children.Clear();               //clears all pawns on board
            for (int y = 0; y <= 2; y++)               //loops
            {
                for (int x = 0; x <= 4; x++)        //loops
                {
                    board[y, x] = boardStart[y, x]; //resets the board
                }
            }
            lblScore.Content = whitePoints.ToString() + " - " + blackPoints.ToString(); //display points
            drawGame();                             //start next game
        }
        private void refreshBoard()
        {   //so, the squares get highlighted when you click them, this just resets the highlight
            A1.Background = Brushes.White;//white squares
            A3.Background = Brushes.White;
            B2.Background = Brushes.White;
            C1.Background = Brushes.White;
            C3.Background = Brushes.White;
            A2.Background = Brushes.Black;//black squares
            B1.Background = Brushes.Black;
            B3.Background = Brushes.Black;
            C2.Background = Brushes.Black;
        }

        /// <summary>
        /// runs after every move. checks if someone has made a wining move, or if it is a tie
        /// </summary>
        private void checkEnd()
        {
            int stalePawns = 0;             //keep track of pawns that cannot move
            for (int y = 0; y < 2; y++)      //go through board[,]
            {
                for (int x = 0; x < 4; x++)
                {
                    //piece makes it to the other end
                    if (board[0, x] == -1)  //white makes it the other side
                    {
                        whitePoints++;      // white getsa point
                        MessageBox.Show("White Wins!");
                        resetGame();

                    }
                    else if (board[2, x] == 1) //black makes it to the other side
                    {
                        blackPoints++;         //black gets a point
                        MessageBox.Show("Black Wins!");
                        resetGame();
                    }
                    //stalemates
                    else if (board[y, x] == 1)                 //if the piece is black
                    {
                        if (board[y + 1, x] != 0)           //if the spot directly below it isn't empty
                        {
                            if (board[y + 1, x + 1] != -1 && board[y + 1, x - 1] != -1)//if the first diagonal position does not have a white piece
                            {
                                stalePawns++; //that pawn cannot move
                                if (stalePawns == blackPawns) //if no black pawns can move, no white pawns can move
                                {
                                    MessageBox.Show("Stalemate!");//tie game
                                    resetGame();
                                }
                            }
                        }
                    }
                    //we only check black pieces for stalemate because if a black piece has no moves,
                    //then white pieces wont have any moves

                    //all pawns are killed
                    else if (blackPawns == 0)           //black has no pawns left
                    {
                        whitePoints++;                  //white wins
                        MessageBox.Show("White Wins!");
                        resetGame();
                    }
                    else if (whitePawns == 0)           //white has no pawns left
                    {
                        blackPoints++;                  //black wins
                        MessageBox.Show("Black Wins!");
                        resetGame();
                    }
                }
            }
            lblStale.Content = stalePawns.ToString(); //debugging
        }

        /// <summary>
        /// draws the game in the starting position.
        /// i could have modified updateBoard() to do this, 
        /// but that required more work, as i was stuck in an infinite loop
        /// and knew this would work as a work-around
        /// </summary>
        private void drawGame()
        {
            for (int y = 0; y <= 2; y++)//check through Y values of the grid
            {
                for (int x = 0; x <= 4; x++)//check through X values of grid
                {

                    if (x != 4)
                    {
                        if (x != 0)
                        {
                            if (board[y, x] == 1)
                            {
                                Ellipse BP = new Ellipse(); //pawn figure
                                BP.Height = pawnDiam;
                                BP.Width = pawnDiam;
                                BP.Fill = Brushes.Black;
                                BP.Stroke = Brushes.White;
                                BP.StrokeThickness = 1;
                                lblBoard.Content += "B";
                                canPawn.Children.Add(BP);
                                Canvas.SetLeft(BP, (100 * (x - 1)) + 5);
                                Canvas.SetTop(BP, (100 * (y)) + 5);
                            }
                            else if (board[y, x] == -1)
                            {
                                Ellipse WP = new Ellipse(); //pawn figure
                                WP.Height = pawnDiam;
                                WP.Width = pawnDiam;
                                WP.Fill = Brushes.White;
                                WP.Stroke = Brushes.Black;
                                WP.StrokeThickness = 1;

                                lblBoard.Content += "W";
                                canPawn.Children.Add(WP);
                                Canvas.SetLeft(WP, (100 * (x - 1)) + 5);
                                Canvas.SetTop(WP, (100 * (y)) + 5);
                            }
                            else
                            {

                                lblBoard.Content += "-";

                            }
                            //lblBoard.Content += board[y, x].ToString();
                        }
                    }
                    //Console.WriteLine(board[y, x].ToString());
                    if (x == 4)
                    {
                        lblBoard.Content += "\n";
                    }
                }
            }
        }
    }
}

