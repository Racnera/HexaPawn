﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
namespace Bot_Testing
{
    class HER
    {
        int nextMoves;
        public static int[,] botBoard= new int[3,5];
        string test = "";
        int turnNum;
        Random r= new Random();
        int moveNum;
        
        public void GetBoard() //gives the computer the newest instance of the game
        {
            
            botBoard = MainWindow.board;
            turnNum = MainWindow.turnCount;
        }
        public void checkBoard()
        {
            if (turnNum == 2) //all possible boards in move 2
            {
               /* if (botBoard[1, 1] == 1)
                {
                    nextMoves = 1;
                }*/
                for(int i =0; i < 5; i++)
                {

                    if (botBoard[1,1] == -1)
                    {
                        moveNum = 1;
                        botBoard[0, 2] = 0;
                        botBoard[1,1]=1;
                    }
                }
            }
            else if (turnNum == 4)
            {

            }
            else if (turnNum==6)
            {

            }                      
           
        }
        public void movePiece()
        {
            checkBoard();
            switch (turnNum)
            {
                case 2:
                    switch (moveNum)
                    {
                        case 1:
                            botBoard[0, 2] = 0;
                            botBoard[1, 1] = 1;
                            break;
                    }
                    break;
            }
            //MainWindow.board = botBoard;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    test += botBoard[i, j];

                }
            }
            MessageBox.Show(test);
        }
    }
}
