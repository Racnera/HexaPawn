﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
namespace Bot_Testing
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// globals 
        /// </summary>
        HER her = new HER();
        public static int[,] board = new int[,]
        {
                {0,1,1,1,0 },
                {0,0,0,0,0 },
                {0,-1,-1,-1,0 }
        };               //this board is changed, checking valid moves, and if the game is over is done on this board
        int[,] boardStart = new int[,] //plceholder board
        {
            {0,1,1,1,0 },//black        //black is 1 so when i check moves later, i can add "turn" and get squares below piece selected
            {0,0,0,0,0 },//blank
            {0,-1,-1,-1,0 }//white      //white is -1 so when i check moves later, i can add "turn" and get squares above piece selected 
        };          //this board never changes, and is only used to reset the board above in resetBoard()
        int blackPawns = 0;                         //black  pawns on board
        int whitePawns = 0;                         //white pawns on board
        int whitePoints = 0;                        //white current points
        int blackPoints = 0;                         //black current points
        Brush b;                                    //saves color of tile before highlighting it
        int turn = -1;                              //white goes first
        public static int turnCount=1;
        bool pieceSelected = false;                   //no piece selected at first
        Button slect;                               //first button press
        Button move;                                //second button press
        /*string strip="btn3x4";
        string stripNum, stripX, stripY;*/               //learning to split
        int slectX, slectY, moveY, moveX;              //so, the buttons generated in drawBoard() have names (btnYxX, where Y and X are integers from 0-2), in order to take the position of these buttons,
                                                       //we split and trim the name of the button until we have a Y value for the button and an X value for the button, then we check board[,] and can move values if we need to 
        /// <summary>
        /// on start up, draws the board
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            drawBoard();
            /*stripNum =strip.Substring(3);         //learning how to split properly
            stripY = stripNum.Split('x')[0];
            stripX = stripNum.Split('x')[1];

            lblMove.Content = stripY+','+ stripX;*/
        }
        /// <summary>
        /// when the game squares are clicked
        /// </summary>
        /// <param name="sender">the button clicked</param>
        /// <param name="e"></param>
        private void button_Click(object sender, RoutedEventArgs e)                             //all 9 buttons use this!
        {
            
            if (pieceSelected == false)                                                         //if you have not yet selected a piece to move:
            {
                slect = (Button)sender;
                //MessageBox.Show(slect.Name);                                                         //button being held as the piece you want to move
                lblSlect.Content = slect.Name;
                slectX = int.Parse(slect.Name.Substring(3).Split('x')[1]);                      //since the name of the buttons willalways be 'btnYxX' we remove the first three characters, and then split on the dividing 'x'
                slectY = int.Parse(slect.Name.Substring(3).Split('x')[0]);
                if (checkSlect() == true)                                                       //uses the ints above to check the grid if you're trying to move your own piece,
                {
                    b = slect.Background;                                                       //saves the original background colour so we can remove the green background later
                    slect.Background = Brushes.Green;                                           //used to signify the piece on this square is selected and trying to be moved
                }
                else { }
                //slect.Content = null;                                                         //debugging, make sure the content of the button can be manipulated
                //MessageBox.Show(slectY);                                                      //make sure im splitting correctly
            }
            else if (pieceSelected == true)                                                     // if you have already selected a piece, then you are trying to move to this square
            {
                move = (Button)sender;                                                          //access the button's info, such as NAME
                lblMove.Content = move.Name.Split('x')[0] + "," + move.Name.Split('x')[1];       //splitting
                moveX = int.Parse(move.Name.Substring(3).Split('x')[1]);                        //finding the button's position on the grid
                moveY = int.Parse(move.Name.Substring(3).Split('x')[0]);
                if (checkMove() == true)                                                        //checks if you can move your piece from the button 'slect' to the new button 'move'
                {
                    slect.Background = b;                                                       //if it works, the highlight on slect is reset
                    movePiece(slect, move);                                                     //moves the piece between the buttons
                    checkEnd();                                                                 //see if a winning move was made
                }
                else { MessageBox.Show("ILLEGAL MOVE"); }                                       //if checkMove returns false, your move is not possible
            }

        }
        /// <summary>
        /// builds the tiles into the wap panel
        /// </summary>
        private void drawBoard()
        {
            for (int i = 0; i < 3; i++)                                                 //loops to create buttons, Y vals
            {
                for (int j = 0; j < 5; j++)                                             //loops through  X vals
                {
                    //visual board
                    if (j > 0 && j < 4)                                                 //dont add buttons on the edges, the 0's at board[y,0] and board[y,4] are for checking stalemates later,
                    {
                        Button btn = new Button();                                      // a new button is made
                        btn.Click += button_Click;                                      //you can click this button
                        btn.Name = "btn" + (i.ToString() + "x" + j.ToString());         //named according to the loop, ties to 'board[,]'
                        btn.Height = btn.Width = 155;                                   //button sizing

                        //MessageBox.Show(((int.Parse(btn.Name.Substring(3).Split('x')[0]) + int.Parse(btn.Name.Substring(3).Split('x')[1]))%2).ToString()); value debugging
                        if ((int.Parse(btn.Name.Substring(3).Split('x')[0]) + int.Parse(btn.Name.Substring(3).Split('x')[1])) % 2 == 1)  //adds y and x components of button, if its odd, it's a white tile.
                                                                                                                                         //since the buttons are named according to the loop, the lowest button number is 01, the highest being 5
                        {
                            btn.Background = Brushes.White;
                        }
                        else { btn.Background = Brushes.Black; }

                        if (i == 0 || i == 2)
                        {
                            drawEllipse(i, btn);                                        //put pawns at the top and the bottom
                        }
                        gameBoard.Children.Add(btn);                                    //add the button to the wrap panel

                        //char board                                                    //not necessary but i like having it, its where the all the checking will be happening. shows 'board[,]' in an easy-to-read fashion 
                        if (board[i, j] == 1)
                        {
                            lblBoard.Content += "B";                                    //B for black
                        }
                        else if (board[i, j] == -1)
                        {
                            lblBoard.Content += "W";                                    //W for white
                        }
                        else { lblBoard.Content += "-"; }                               //empty squares are '-'
                        if (j == 3)
                        {
                            lblBoard.Content += "\n";
                        }
                    }
                    

                }

            }
        }
        private void drawEllipse(int color, Button b)
        {
            Ellipse EL = new Ellipse();
            EL.Height = EL.Width = 90;
            EL.StrokeThickness = 1;
            if (color == 1)
            {
                EL.Fill = Brushes.Black;
                EL.Stroke = Brushes.White;
            }
            else if (color == -1)
            {
                EL.Fill = Brushes.White;
                EL.Stroke = Brushes.Black;
            }
            b.Content = EL;

        }
        private bool checkSlect() //are you trying to move your own piece
        {
            if (board[slectY, slectX] == turn)          //since turns and colors are represented by the same numbers, if you are black (turn=1) you can only move black pieces (board[slectY,slectX]==1)
            {
                pieceSelected = true;
                return true;
            }
            else { MessageBox.Show("ERROR, NOT VALID PIECE"); return false; }   //you must not have selected a square with your piece on it
        }
        private bool checkMove() //if return true, make move, else deselect piece
        {
            if (slectY + turn == moveY && slectX == moveX && board[moveY, moveX] == 0)      //moving forward,
            {
                board[moveY, moveX] = board[slectY, slectX];
                board[slectY, slectX] = 0;
                return true;
            }
            else if ((slectY + turn == moveY) && (slectX + turn == moveX || slectX - turn == moveX) && board[moveY, moveX] == turn * -1)    //capturing, this is why board[,] is [3,5]
            {
                board[moveY, moveX] = board[slectY, slectX];
                board[slectY, slectX] = 0;
                return true;
            }
            else { pieceSelected = false; slect.Background = b; return false; }    //illegal move
        }

        private void btnTest_Click(object sender, RoutedEventArgs e)
        {
            HER her = new HER();
            her.GetBoard();
        }                                                   ///TEST BUTTON 

        private void movePiece(Button selected, Button moving)
        {
            if (turnCount % 2 == 1)
            {
                lblTunrCount.Content = turnCount.ToString();
                moving.Content = selected.Content;              //take the piece in the first button you click, move it to the second
                selected.Content = null;                        //clear the first button
                turn *= -1;                                     //switch turns
                pieceSelected = false;                          //no longer selecting a piece
                blackPawns = whitePawns = 0;                    //tally pawns, in case one was captured, and for checking stalemates
                lblBoard.Content = "";                          //rebuild character board
                turnCount++;                
            }
            updateCharBoard();
            Thread.Sleep(150);
            her.GetBoard();
            her.movePiece();
            updateCharBoard();

        }

        private void checkEnd()
        {
            int stalePawns = 0;                                                     //keep track of pawns that cannot move
            for (int y = 0; y < 3; y++)                                             //go through board[,]
            {
                for (int x = 0; x < 5; x++)
                {
                    //piece makes it to the other end
                    if (board[0, x] == -1)                                          //white makes it the other side
                    {
                        whitePoints++;                                              // white getsa point
                        MessageBox.Show("Player Wins!");
                        resetGame();

                    }
                    if (board[2, x] == 1)                                          //black makes it to the other side
                    {
                        blackPoints++;                                              //black gets a point
                        MessageBox.Show("Computer Wins!");
                        resetGame();
                    }
                    //stalemates
                    else if (board[y, x] == 1)                                      //if the piece is black
                    {
                        if (board[y + 1, x] != 0)                                   //if the spot directly below it isn't empty
                        {
                            if (board[y + 1, x + 1] != -1 && board[y + 1, x - 1] != -1)//if the first diagonal position does not have a white piece
                            {
                                stalePawns++;                                       //that pawn cannot move
                                if (stalePawns == blackPawns)                       //if no black pawns can move, no white pawns can move
                                {
                                    MessageBox.Show("Stalemate! Player Wins!");                  //tie game
                                    resetGame();
                                }
                            }
                        }
                    }
                    //we only check black pieces for stalemate because if a black piece has no moves,
                    //then white pieces wont have any moves
                    //all pawns are killed
                    else if (blackPawns == 0)                                       //black has no pawns left
                    {
                        whitePoints++;                                              //white wins
                        resetGame();
                        MessageBox.Show("Player Wins!");
                        break;
                    }
                    else if (whitePawns == 0)                                       //white has no pawns left
                    {
                        blackPoints++;                                              //black wins
                        resetGame();
                        MessageBox.Show("Computer Wins!");
                        break;

                    }
                }
            }
            lblStale.Content = stalePawns.ToString();                               //debugging
        }
        private void resetGame()
        {
            blackPawns = 1;
            whitePawns = 1;
            turnCount = 0;
            turn = -1;                                  //white starts
            lblBoard.Content = "";                      //clear this so it'll look pretty when the game restarts
            gameBoard.Children.Clear();
            for (int y = 0; y <= 2; y++)                //loops
            {
                for (int x = 0; x <= 4; x++)            //loops
                {
                    board[y, x] = boardStart[y, x];     //resets the board
                }
            }
            lblScore.Content = ("White: " + whitePoints.ToString() + "\nBlack:" + blackPoints.ToString()); //update score
            drawBoard();                                                                                   //restart the game
        }
        public void updateCharBoard()
        {
            lblBoard.Content = "";
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    if (j < 4 & j > 0)
                    {
                        if (board[i, j] == 1)
                        {
                            blackPawns++;
                            lblBoard.Content += "B";
                        }
                        else if (board[i, j] == -1)
                        {
                            whitePawns++;
                            lblBoard.Content += "W";
                        }
                        else { lblBoard.Content += "-"; }
                        if (j == 3)
                        {
                            lblBoard.Content += "\n";
                        }
                    }

                }

            }
        }
    }
}
