﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;
namespace WpfApp1
{
    class Board
    {
        public static Rectangle[,] map;
        public int[,] playerPos;
        public int[,] blackPos;
        public int[,] whitePos;
        public int[,] grid;

        public Board()
        {
            playerPos = new int[,] 
            {
                {1,1,1 }, //black pawns
                {0,0,0 }, //empty squares
                {2,2,2 } //white pawns
            };
            whitePos = new int[,]
            {
                {0,0,0 }, //black pawns
                {0,0,0 }, //empty squares
                {1,1,1 } //white pawns
            };
            blackPos = new int[,]
             {
                {1,1,1 }, //black pawns
                {0,0,0 }, //empty squares
                {0,0,0 } //white pawns
             };
            grid = new int[,]
            {
                {0,1,2 },
                {0,1,2 },
                {0,1,2 }
            };
        }
        public void updateBoard()
        {

        }
    }
}
