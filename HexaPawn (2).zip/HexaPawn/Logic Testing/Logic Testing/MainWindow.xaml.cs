﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Logic_Testing
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// globals
        /// </summary>
        char[] letter = { 'C', 'B', 'A'};
        char[] num = {'1','2','3'};
        
        int[,] board = new int[,]
        {
            {1,1,1 },//black
            {0,0,0 },//blank
            {2,2,2 }//white
        };
        string positionSelect="";
        bool pieceSelected = false;
        int slectX;
        int slectY;
        int turn = 1; //-1=white, 1=black
        int moveX;
        int moveY;

        public MainWindow()
        {
            InitializeComponent();
            updateBoard();
            lblTurn.Content = "Black's Turn!";
        }

        private void C3_Click(object sender, RoutedEventArgs e)
        {
            if (pieceSelected == false)                                     ///FIX THIS ON ALL OF THEM
            {
                slectX = 2;
                slectY = 0;
            }
            pieceSelect();
        }

        private void C2_Click(object sender, RoutedEventArgs e)
        {
            slectX = 1;
            slectY = 0;
            pieceSelect();
        }

        private void C1_Click(object sender, RoutedEventArgs e)
        {
            slectX = 0;
            slectY = 0;
            pieceSelect();
        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {
            slectX = 2;
            slectY = 1;
            pieceSelect();
            if (turn == 1)
            {
                if (pieceSelected == true)
                {
                    moveX = 2;
                    moveY = 1;
                    checkMove();
                }
            }
            
        }

        private void B2_Click(object sender, RoutedEventArgs e)
        {
            slectX = 1;
            slectY = 1;
            pieceSelect();
            if (turn == 1)
            {
                if (pieceSelected == true)
                {
                    moveX = 1;
                    moveY = 1;
                    checkMove();
                }
            }
            //Console.WriteLine(turn.ToString());
        }
        private void B1_Click(object sender, RoutedEventArgs e)
        {
            slectX = 1;
            slectY = 1;
            pieceSelect();
        }
        private void A3_Click(object sender, RoutedEventArgs e)
        {
            slectX = 2;
            slectY = 2;
            pieceSelect();
        }

        private void A2_Click(object sender, RoutedEventArgs e)
        {
            slectX = 1;
            slectY = 2;
            pieceSelect();

        }

        private void A1_Click(object sender, RoutedEventArgs e)
        {
            slectX = 0;
            slectY = 2;
            pieceSelect();
        }

        private void updateBoard()
        {
            pieceSelected = false;
            lblBoard.Content = "";
            for (int y = 0; y <= 2; y++)
            {
                for (int x = 0; x <= 2; x++)
                {
                    
                    lblBoard.Content += board[y, x].ToString();
                    //Console.WriteLine(board[y, x].ToString());
                    if (x == 2)
                    {
                        lblBoard.Content += "\n";
                    }
                }
            }
        }


        private void checkMove()
        {
            if ((moveY == slectY + turn) && (moveX == slectX) && board[moveY, moveX] == 0) //check if moving to a legal, empty tile (not diag, sideways, or more than 1 square//
            {
                board[moveY, moveX] = 1;
                board[slectY, slectX] = 0;
                updateBoard();

                if (turn == 1)
                {
                    lblTurn.Content = "White's Turn!";
                    turn -= 2;
                }
                else if (turn == (-1))
                {
                    turn += 2;
                    lblTurn.Content = "Black's Turn!";

                }
            }
            else { Errors.Content = "Invalid Move"; }          
        }





        private void pieceSelect()
        {
            if (pieceSelected == false)
            {
                lblSelected.Content = letter[slectY].ToString() + num[slectX].ToString();
                if (turn == 1) //if its black's turn
                {
                    if (board[slectY, slectX] == 1) //if selecting a black piece
                    {
                        pieceSelected = true;
                    }
                    else
                    {
                        pieceSelected = false;
                        Errors.Content = "invalid square selected";
                    }
                }

                else if (turn == (-1))
                {
                    if (board[slectY, slectX] == 2) //if selecting a white piece
                    {
                        pieceSelected = true;
                    }
                    else
                    {
                        pieceSelected = false;
                        Errors.Content = "invalid square selected";
                    }
                }
            
            }
        }
    }
}
