﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for GameWindow.xaml
    /// </summary>
    public partial class GameWindow : Window
    {
        /// <summary>
        /// Globals
        /// </summary>
        int turn = 0; //who's turn it is, 0 is white, 1 is black
        int colour;
        bool selected = false;
        int selectX;
        int selectY;
        int futureX;
        int futureY;
        Board board = new Board();
        public GameWindow()
        {
            InitializeComponent();
            int[,] board = new int[3,3];

        }

        private void A1_Click(object sender, RoutedEventArgs e)
        {
            if(selected == false)
            {
                selectX = 0;
                selectY = 2;
            }
            
            //Console.WriteLine(board.playerPos[2, 0]);
            if ((board.playerPos[2,0]==1 || board.playerPos[2, 0] == 2) && selected==false)
            {
                colour = board.playerPos[2, 0];
                
                board.playerPos[2,0] = 0;
                selected = true;
            }
            else { }
        }

        private void A2_Click(object sender, RoutedEventArgs e)
        {

            if (selected == true)
            {
                if (turn == 0)
                {
                    if(colour!=board.playerPos[selectY-1,selectX] | colour!=board.playerPos[selectY - 1, selectX - 1])
                    {

                    }
                }
                
            }
            //Console.WriteLine(board.playerPos[2, 1]);
             
        }

        private void A3_Click(object sender, RoutedEventArgs e)
        {
            //Console.WriteLine(board.playerPos[2, 2]);

        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            
            
            //Console.WriteLine(board.playerPos[1, 0]);
            if (selected == true)
            {
                futureX = 0;
                futureY = 1;
                if (turn == 0)
                {
                    if (colour != board.playerPos[selectY - 1, selectX] | 
                        colour != board.playerPos[selectY - 1, selectX - 1])
                    {
                        
                    }
                }

            }
        }

        private void B2_Click(object sender, RoutedEventArgs e)
        {
            //Console.WriteLine(board.playerPos[1, 1]);

        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {
            Console.WriteLine(board.playerPos[1, 2]);

        }

        private void C1_Click(object sender, RoutedEventArgs e)
        {
            Console.WriteLine(board.playerPos[0, 0]);

        }

        private void C2_Click(object sender, RoutedEventArgs e)
        {
            Console.WriteLine(board.playerPos[0,1]);

        }

        private void C3_Click(object sender, RoutedEventArgs e)
        {
            Console.WriteLine(board.playerPos[0, 2]);
        }
    }
}
