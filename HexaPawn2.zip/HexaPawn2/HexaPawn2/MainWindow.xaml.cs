﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HexaPawn2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            drawBoard();
        }
        
        private void drawBoard()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Button btn = new Button();
                    btn.Click += button_Click;
                    btn.Name = "btn"+(i.ToString()+"," +j.ToString());
                    btn.Height = btn.Width = 155;
                    if (i < 3 || i > 5)
                    {
                        drawEllipse(btn);
                    }
                    gameBoard.Children.Add(btn);
                }
               
            }
            

        }
        private void button_Click(object sender, RoutedEventArgs e)
        {
            Button b = (Button)sender;
            MessageBox.Show(b.Name);

        }
        private void drawEllipse(Button btn)
        {
            Ellipse el = new Ellipse();
            el.Height = el.Width = 135;
            el.Fill = Brushes.Red;
            btn.Height = btn.Width = 155;
            btn.Content = el;
        }
    }
}
